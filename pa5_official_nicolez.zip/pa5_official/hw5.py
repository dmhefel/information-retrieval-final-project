from flask import Flask, render_template
from elasticsearch_dsl.connections import connections
from flask import Flask, render_template, request
from embedding_service.client import EmbeddingClient
from evaluate import bm25_custom_search, bm25_default_search, reranking_embedding

app = Flask(__name__)
docid_list = []  # int list that holds the ranking id list for search results
# [ 0: {"date": hit.date, "title": hit.title, "content": hit.content, "author": hit.author}, 1: {...}, ...]
page_id = 1  # initial page id
list_size = 0
initial_query = ""
curr_page = 1
k = 20
index_name = "wapo_docs_50k"

# home page
@app.route("/")
def home():
    return render_template("home.html")


# result page
@app.route("/results", methods=["POST"])
def results():
    global docid_list  # To assure the docid_list is updated in the global variable with the same name
    global list_size
    global initial_query
    global page_id
    global curr_page
    global index_name
    global k
    page_id = 1
    curr_page = 1
    docid_list = []
    list_size = 0
    query_text = request.form["query"]  # Get the raw user query from home page
    search_type = request.form["search_type"] # Get the search method from the checkboxes in the home page
    initial_query = query_text

    # call the search method that corresponds to the search_type the user selected
    # asign the results list to the docid_list because that is the global var that is updated
    if search_type == "bm25-analyzer":
        relevance_scores, results_list = bm25_default_search(initial_query, index_name, k)
        docid_list = results_list
    elif search_type == "bm25-custom":
        relevance_scores, results_list = bm25_custom_search(initial_query, index_name, k)
        docid_list = results_list
    elif search_type == "sbert":
        encoder = EmbeddingClient(host="localhost", embedding_type="sbert")
        q_vec_encoder = encoder.encode([initial_query], pooling="mean").tolist()[0]
        relevance_scores, results_list = reranking_embedding(index_name, initial_query, q_vec_encoder, k, "sbert_vector")
        docid_list = results_list
    else:
        encoder = EmbeddingClient(host="localhost", embedding_type="fasttext")  # connect to the fasttext embedding server
        q_vec_encoder = encoder.encode([initial_query], pooling="mean").tolist()[0]
        relevance_scores, results_list = reranking_embedding(index_name, initial_query, q_vec_encoder, k,
                                                             "ft_vector")
        docid_list = results_list
    list_size = len(docid_list)

    return render_template("results.html", docid_list=docid_list, page_id=1,
                           list_size=list_size, initial_query=initial_query, curr_page=curr_page)


# "next page" to show more results
@app.route("/results/<int:page_id>", methods=["POST"])
def next_page(page_id):
    global docid_list  # access the original/latest doc_id list
    global curr_page
    curr_page = page_id
    docid_list = docid_list[8:]  # start from the 9th element, since the previous 8 were already displayed
    list_size = len(docid_list)
    return render_template("results.html", docid_list=docid_list, page_id=page_id,
                           list_size=list_size, initial_query=initial_query, curr_page=curr_page)


# document page
@app.route("/doc_data/<int:doc_id>")
def doc_data(doc_id):
    global docid_list
    doc_id = doc_id % 8
    author = docid_list[doc_id]["author"]
    title = docid_list[doc_id]["title"]
    date = docid_list[doc_id]["date"]
    content = docid_list[doc_id]["content"]
    return render_template("doc.html", author=author, title=title, date=date, content=content)


if __name__ == "__main__":
    connections.create_connection(hosts=["localhost"], timeout=100, alias="default")
    app.run(debug=True, port=5000)
