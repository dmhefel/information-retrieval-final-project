#Author: Daniel Hefel
from typing import List
from gensim.models.doc2vec import Doc2Vec
from nltk.tokenize import word_tokenize
from elasticsearch_dsl import Search
from elasticsearch_dsl.query import Match, MatchAll, ScriptScore, Ids, Query
from elasticsearch_dsl.connections import connections
from embedding_service.client import EmbeddingClient
from metrics import Score

encoder = EmbeddingClient(host="localhost", embedding_type="sbert")


def generate_script_score_query(query_vector: List[float], vector_name: str) -> Query:
    """
    generate an ES query that match all documents based on the cosine similarity
    :param query_vector: query embedding from the encoder
    :param vector_name: embedding type, should match the field name defined in BaseDoc ("ft_vector" or "sbert_vector")
    :return: an query object
    """
    q_script = ScriptScore(
        query={"match_all": {}},  # use a match-all query
        script={  # script your scoring function
            "source": f"cosineSimilarity(params.query_vector, '{vector_name}') + 1.0",
            # add 1.0 to avoid negative score
            "params": {"query_vector": query_vector},
        },
    )
    return q_script


def search(index: str, query: Query) -> None:
    s = Search(using="default", index=index).query(query)[
        :20
    ]  # initialize a query and return top five results
    response = s.execute()
    for hit in response:
        print(
            hit.meta.id, hit.meta.score, hit.title, hit.annotation, sep="\t"
        )  # print the document id that is assigned by ES index, score and title
        #print(hit.content)
    print(response.hits.total)

    return response

def getscores(x,id):
    """
    Author:Daniel Hefel
    this function takes in the search object and then gets the scores
    :param x:
    :return:
    """
    relevance = []
    for hit in x:
        #print(hit.meta.id, hit.meta.score, hit.title, hit.annotation, sep="\t")
        if hit.annotation == id+"-2":
            relevance.append(2)
        elif hit.annotation == id+"-1":
            relevance.append(1)
        else:
            relevance.append(0)
    score = Score.eval(relevance, 20)
    print("NDCG, PREC, aveprec", score.ndcg, score.prec, score.ap)

if __name__ == "__main__":
    id = "439"
    connections.create_connection(hosts=["localhost"], timeout=100, alias="default")
    #439 title
    #query__ = "inventions, scientific discoveries"
    #439 description
    #query__ = "What new inventions or scientific discoveries have been made?"
    #439 narrative
    #query__= 'The word "new" in the description is defined as occurring in the 1990s. Documents that indicate a "recent" invention or scientific discovery are considered relevant. Discoveries made in astronomy or any scientific discoveries that are not patentable are not relevant.  '
    #Additional queries tested
    #query__ = "science discovery astronomy"
    query__ = "science discovery patent"
    q_basic = Match(
        content={"query": query__}
    )  ## a query that matches "D.C" in the title field of the index, using BM25 as default

    #turn query into a string in a list
    query_text = [query__]
    query_vector = encoder.encode(query_text, pooling="mean").tolist()[
        0
    ]  # get the query embedding and convert it to a list
    q_vector = generate_script_score_query(
        query_vector, "sbert_vector"
    )  # custom query that scores documents based on cosine similarity


    #This searched in the custom index in my machine
    x = search(
        "custom_idx", q_vector
    )  # search, change the query object to see different results

    #this searched in the new sbert index
    y = search(
        "new_sbert_idx", q_vector #new_sbert_idx
    )
    #this gets the results from both the original custom bm25 and then the new sbert
    getscores(x,id)
    getscores(y,id)


# processing the doc2vec

#Get vector for query:
    model= Doc2Vec.load("d2v.model")
    test_data = word_tokenize(query__.lower())
    v1 = model.infer_vector(test_data).tolist()
    q_vec = generate_script_score_query(
            v1, "doc2vec"
        )
    x = search(
            "doc2vec_idx", q_vec
        )
    #this gets the scores for the doc2vec search
    getscores(x,id)
