#Author: Daniel Hefel

from pathlib import Path
import json, jsonlines
import numpy as np
from utils import load_wapo
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('msmarco-distilbert-base-v3')
#global variable for determing how long the text for chunking and going into sbert encoder
CHUNKSIZE = 300


def chunk_text(doc):
    """
    This functiion divides a doc string into a list and then makes a list of lists of that length of words
    :param doc: content string
    :return: list of lists of length chunksize
    """
    #doc is the string representing the text of document
    tokens = doc.split()
    chunked_tokens = [tokens[i:i + CHUNKSIZE] for i in range(0, len(tokens), CHUNKSIZE)]
    return [" ".join(i) for i in chunked_tokens]




#write to file
with jsonlines.open('data/with_avg_sbert.jl', mode='a') as writer:
    #get the path for the file you are reading in
    data_dir = Path("data")
    wapo_path = data_dir.joinpath('subset_wapo_50k_sbert_ft_filtered.jl')
    wapo = load_wapo(wapo_path)
    article = next(wapo, '')
    while article:
        #chunk the text
        chunked_text = chunk_text(article['content_str'])
        #create embeddings for text
        embeddings = model.encode(chunked_text)
        #if embeddings length >1, need to average the embeddings
        if len(embeddings) > 1:
            averaged_embedding = embeddings[0]
            for i in range(1, len(embeddings)):
                averaged_embedding += embeddings[i]
            averaged_embedding = averaged_embedding / len(embeddings)
        else:
            averaged_embeddding = embeddings
        #add to dictionary
        article['new_sbert'] = averaged_embedding.tolist()
        #write to file
        writer.write(article)
        #get next article
        article = next(wapo, '')

