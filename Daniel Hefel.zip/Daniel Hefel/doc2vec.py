#Author: Daniel Hefel

from gensim.models.doc2vec import Doc2Vec, TaggedDocument
from nltk.tokenize import word_tokenize
import jsonlines, json
from pathlib import Path
from utils import load_wapo

#Get a list of all content strings for the model to train on
data_dir = Path("data")
wapo_path = data_dir.joinpath("subset_wapo_50k_sbert_ft_filtered.jl")
data = [doc['content_str'] for doc in load_wapo(wapo_path)]
#Tag and tokenize data
tagged_data = [TaggedDocument(words=word_tokenize(_d.lower()), tags=[str(i)]) for i, _d in enumerate(data)]
#hyperparameters
max_epochs = 20
vec_size = 50
alpha = 0.025

model = Doc2Vec(vector_size=vec_size,
                alpha=alpha,
                min_alpha=0.00025,
                min_count=1,
                dm=1)

model.build_vocab(tagged_data)
#Train the model
for epoch in range(max_epochs):
    print('iteration {0}'.format(epoch))
    model.train(tagged_data,
                total_examples=model.corpus_count,
                epochs=max_epochs)
    # decrease the learning rate
    model.alpha -= 0.0002
    # fix the learning rate, no decay
    model.min_alpha = model.alpha
#Save the model
model.save("d2v.model")
print("Model Saved")
#Load the saved model
model= Doc2Vec.load("d2v.model")

#Open the 50k file again and get write the trained vector to a file with the original info
with jsonlines.open('data/with_doc2vec.jl', mode='a') as writer:
    id = 0
    wapo = load_wapo(wapo_path)
    article = next(wapo, '')
    while article:
        article['doc2vec'] = model.dv[str(id)].tolist()
        writer.write(article)
        #print(id, article['title'])
        id+=1
        article = next(wapo, '')
