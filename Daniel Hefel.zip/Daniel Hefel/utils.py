#Author: Daniel Hefel
import json, jsonlines
import numpy as np


def load_wapo(wapo_jl_path):
    """
    This function loads the 50k corpus and creates a generator object for the doc dictionaries
    """
    # open the jsonline file
    with open(wapo_jl_path) as f:
        # get line
        line = f.readline()
        # id number
        id = 0
        # while line not empty
        while line:
            # load line as json
            article = json.loads(line)

            # create dict for the article
            articledict = {'doc_id': article["doc_id"],
                           'title': article["title"] if article['title'] is not None else '',
                           "author": article["author"] if article['author'] is not None else '',
                           "published_date": article['published_date'],
                           "content_str": article['content_str'],
                           "annotation": article['annotation'],
                           # "sbert_vector": article['sbert_vector'], #do we need?
                           # "ft_vector": article['ft_vector'], #do we need?
                           }
            # increment id (this was used to check progress and isn't actually needed in the code)
            id += 1
            # get next line
            line = f.readline()
            # yield the dictionary (generator object)
            yield articledict
